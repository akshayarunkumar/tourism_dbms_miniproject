function myFunction(){
    para1.style.display = 'none';
    alert("The Time is mentioned is on Rough , So please be before few minutes");

}
function toggleHide(){
    // let btn = document.getElementById('btn');
    let para1 = document.getElementById('para1');
    if(para1.style.display != 'none'){
    para1.style.display = 'none';
    // This code is written to change inner line of button
    document.getElementById('btn1').innerHTML = "Show Details";
    }
    else{
        para1.style.display = 'block';
         // This code is written to change inner line of button
        document.getElementById('btn1').innerHTML = "Hide Details";
    }
}



// let para = document.getElementById('para');
// para.addEventListener('mouseout', function run(){
//     alert('Dont take out of para');
// });

