"SELECT bus,time,booking  FROM transport where pid=1"

SELECT bus,time,booking from tranport  WHERE  pid=1

$sql = "SELECT t.bus,t.time,t.booking,h.hname  FROM transport t , hotel h where t.pid=1 AND h.pid=1";


?php
$conn = mysqli_connect("localhost:3307", "root", "", "tourism_db");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT h.hname, t.bus,t.time,t.booking,t.destination FROM hotel h, transport t  where h.pid=t.pid=1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["bus"]. "</td><td>" . $row["time"]."</td><td>" . $row["booking"] ."</td><td>" . $row["hname"]. "</td><td>" . $row["destination"].   "</td></tr>";
"<hr><hr>";
 
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>